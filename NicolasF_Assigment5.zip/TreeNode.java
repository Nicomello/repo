package application;

public class TreeNode<T> {
	protected TreeNode<T> right;
	protected TreeNode<T >left = null;
	private T data = null;

	
	public TreeNode(T dataNode) {
		data = dataNode;
	}

	
	public TreeNode(TreeNode<T> node) {
		left = node.left;
		right = node.right;
		data = node.data;
	}

	
	public T getData() {
		return data;
	}
}