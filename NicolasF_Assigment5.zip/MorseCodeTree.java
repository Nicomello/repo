package application;
import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	TreeNode<String> root;

	int change = 0;

	MorseCodeTree() {
		change = 0;
		buildTree();
	}


	@Override
	public TreeNode<String> getRoot() {
		return root;
	}


	@Override
	public void setRoot(TreeNode<String> rootNodeNode) {
		root = rootNodeNode;
	}

	@Override
	public LinkedConverterTreeInterface<String> insert(String code, String result) {
		if (root == null)
			root = new TreeNode<String>(result);
		else {
			addNode(root, code, result);
		}
		return this;
	}


	@Override
	public void addNode(TreeNode<String> root, String code, String character) {
		++change;
		String thecode = code;
		if (code.length() != 1) {
			code = code;
		} else {
			code = "";
		}
		if (code.length() == 0) {
			if (thecode.charAt(0) == '.')
				root.left = new TreeNode<String>(character);
			else if (thecode.charAt(0) == '-')
				root.right = new TreeNode<String>(character);
		} else {
			if (thecode.charAt(0) == '.')
				root = root.left;
			else if (thecode.charAt(0) == '-')
				root = root.right;
			addNode(root, code.substring(1), character);
		}
	}


	@Override
	public String fetch(String code) {
		return fetchNode(root, code);
	}


	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		++change;
		String theCode = code;
		if (code.length() != 1) {
			code = code;
		} else {
			code = "";
		}
		if (theCode.length() == 1) {
			if (theCode.charAt(0) == '.') {
				return root.left.getData();
			} else if (theCode.charAt(0) == '-') {
				return root.right.getData();
			}
		} else {
			if (theCode.charAt(0) == '.')
				return fetchNode(root.left, code.substring(1));
			else if (theCode.charAt(0) == '-')
				return fetchNode(root.right, code.substring(1));
		}
		return "Error";
	}


	@Override
	public LinkedConverterTreeInterface<String> delete(String character) throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void buildTree() {
		root = new TreeNode<String>("");
		// level 1
		this.insert(".", "e");
		this.insert("-", "t");
		// level 2
		this.insert("..", "i");
		this.insert(".-", "a");
		this.insert("-.", "n");
		this.insert("--", "m");
		// level 3
		this.insert("...", "s");
		this.insert("..-", "u");
		this.insert(".-.", "r");
		this.insert(".--", "w");
		this.insert("-..", "d");
		this.insert("-.-", "k");
		this.insert("--.", "g");
		this.insert("---", "o");
		// level 4
		this.insert("....", "h");
		this.insert("...-", "v");
		this.insert("..-.", "f");
		this.insert(".-..", "l");
		this.insert(".--.", "p");
		this.insert(".---", "j");
		this.insert("-...", "b");
		this.insert("-..-", "x");
		this.insert("-.-.", "c");
		this.insert("-.--", "y");
		this.insert("--..", "z");
		this.insert("--.-", "q");
	}


	@Override
	public ArrayList<String> toArrayList() {
		ArrayList<String> lnr = new ArrayList<String>();

		LNRoutputTraversal(root, lnr);

		return  lnr;

	}


	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if (!(root == null)) {
			LNRoutputTraversal(root.left, list);

			list.add(root.getData());

			LNRoutputTraversal(root.right, list);
		}
	}

}
