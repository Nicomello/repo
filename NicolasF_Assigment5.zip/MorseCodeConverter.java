package application;
import java.io.File;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.Scanner;

public class MorseCodeConverter {
	private static MorseCodeTree morseCodeTree = new MorseCodeTree();

	public static String convertToEnglish(String code) {
		String splitCode[] = code.split(" ");
		String data = "";
		int i = 0;

		while (i < splitCode.length) {

			String c = splitCode[i];

			if (c.matches("/")) {

				data = data + " ";

			}

			else {

				data = data + morseCodeTree.fetch(c);

			}

			i++;

		}
		return data;
	}


	public static String convertToEnglish(File codeFile) throws FileNotFoundException {

		Scanner sc = new Scanner(codeFile);
		String data = "";
		while(sc.hasNextLine()) {

			data = sc.nextLine();

			data += convertToEnglish(data);

		}

		return data;

	}
	
	public static String printTree() {

		String printTheTree = Arrays.toString(morseCodeTree.toArrayList().toArray());
		printTheTree = printTheTree.substring(1, printTheTree.length() - 1);
		String splitCode[] = printTheTree.split(",");
		printTheTree = "";

		for (int i = 0; i < splitCode.length; i++) {

			printTheTree += splitCode[i];

		}
		return printTheTree;

	}
}
