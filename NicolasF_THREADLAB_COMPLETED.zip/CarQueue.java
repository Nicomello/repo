package application;
import java.util.PriorityQueue;
import java.util.Random;


public class CarQueue {


	Random ran = new Random();
	PriorityQueue<Integer> queue = new PriorityQueue<Integer>();
	private int out;

	public CarQueue(){

		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));
		queue.add(ran.nextInt(4));



	}

	public void addToQueue() {

		class ARunnable implements Runnable
		{

			public void run()
			{

				try
				{
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));
					queue.add(ran.nextInt(4));


				}
				finally
				{

				}
			}
		}
		Runnable run1 = new ARunnable();
		Thread thread1 = new Thread(run1);

		thread1.start();  
	}

	public int deleteQueue() {

		class ARunnable implements Runnable
		{


			public void run()
			{

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {

				}


				try
				{
					if(queue.size() < 20){
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));
						queue.add(ran.nextInt(4));

					}

					else if (!queue.isEmpty()){
						out = queue.remove();
					}


				}
				finally
				{

				}
			}

		}
		Runnable run2 = new ARunnable();
		Thread thread2 = new Thread(run2);

		thread2.start();


		return out;

	}

}

