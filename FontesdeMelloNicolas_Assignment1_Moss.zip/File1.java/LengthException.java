package PASWORD;

public class LengthException extends RuntimeException{
	public LengthException() {
		
	}
	public LengthException(String message) {
		super(message);
	}
	
}
